Requirements:
JavaFX-SDK-16 Version 16
JavaJDK 17
JRE: JavaSE-1.8 - jdk 14.0.1

Compiling file:
	Turn on terminal/Command Line:
	Type: cd directory to application folder contains .class files
		Example: Cd D:\SWPro\SupperMarket\bin
	Type: java application.Main

Test Data for Check out Use Case:
	Cashier Log in: 
		ID: 1234
		Password: 1234
	Get on check out system
		{Get Item's Description:
			Click on bardcode Tab: 
			Click on Scan:
				Go to Barcode folder
				Chose: 123456789012.png
		}
		{Customer Login:
			Phone: 1112223333
			Password: 1234
		}
		{Get Item's Description:
			Click on Enter ID Tab:
			Enter onText Field ID: 3
			Click ITEM-ID button
		}	
		{Item's description:
			Click on SCALE
		}
		{Receipt
			Click on TOTAL
		}
		{Make Payment:
			Click on cash Tab: 
				Enter: 5
				Click Enter Cash
			Click on check Tab:
				Click Scan Check
				Go to Check folder
				Chose: 1156.jpg
			Click on Credit/Debit Tab
				Click on Pay By Credit/Debit
				Go to Card folder
				Chose: 123412341.jfif
		}
Test Data for Inventory Management:
{Inventory Management:
	Click on Find Item Under Threshold Button
	Click on search
	{List of Order:
		Click on the number on the column "OrderId"
	}
	{Manage Order:
		Enter the time to send the inventory order: Hour and Minute
		Wait for time match to the system time
		Click on search
		{
			List of orders are change:
			Click on the last number on "OrderID"
		}
	}
}
