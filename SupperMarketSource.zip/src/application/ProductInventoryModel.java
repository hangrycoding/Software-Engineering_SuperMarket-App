package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class ProductInventoryModel {
    
    private Connection conn = null;
    
    private String productName, productDesc, productType, notification;
    private double productPrice;
    private int productId, numAvail, threshold, noOfOrder, supplierID, supplierName;
    
    ProductInventoryModel(Connection conn){
        this.conn = conn;
    }
    ProductInventoryModel(){
    	
    }
    
    synchronized void setConnection(Connection conn) {
    	this.conn = conn;
    }
    
    public ProductInventoryModel[] getSearchItemList(int start, int end, String searchKey)  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[end - start + 1];
    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID and P.productName Like \""+searchKey +"\" limit "+ start  +","+ end ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         int i = 0;
         while (rs.next())
         {
        	 itemList[i] = new ProductInventoryModel();
        	 itemList[i].setProductId(rs.getInt("productId"));
        	 itemList[i].setProductName(rs.getString("productName"));
        	 itemList[i].setProductDesc(rs.getString("description"));
        	 itemList[i].setProductType( rs.getString("type"));
        	 itemList[i].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[i].setNumAvail( rs.getInt("numAvail"));
        	 itemList[i].setThreshold(rs.getInt("threshold"));
        	 itemList[i].setSupplierID( rs.getInt("supplierID"));
        	 itemList[i].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[i].setSupplierName( rs.getInt("supplierName"));
        	 itemList[i].setNotification(rs.getString("notification"));
        	 i++;
         }

         
    	return itemList;
    }
    
    public ProductInventoryModel[] getItemList(int start, int end)  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[end - start + 1];
    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID limit "+ start  +","+ end ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         int i = 0;
         while (rs.next())
         {
        	 itemList[i] = new ProductInventoryModel();
        	 itemList[i].setProductId(rs.getInt("productId"));
        	 itemList[i].setProductName(rs.getString("productName"));
        	 itemList[i].setProductDesc(rs.getString("description"));
        	 itemList[i].setProductType( rs.getString("type"));
        	 itemList[i].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[i].setNumAvail( rs.getInt("numAvail"));
        	 itemList[i].setThreshold(rs.getInt("threshold"));
        	 itemList[i].setSupplierID( rs.getInt("supplierID"));
        	 itemList[i].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[i].setSupplierName( rs.getInt("supplierName"));
        	 itemList[i].setNotification(rs.getString("notification"));
        	 i++;
         }

         
    	return itemList;
    }
    public ProductInventoryModel[] getItemSearchUnderThresholdList(int start, int end, String searchKey)  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[end - start + 1];
    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID and (P.threshold >= (P.numAvail  + p.noOfOrder)) and P.productName Like \"" + searchKey +"\" limit "+ start  +","+ end ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         int i = 0;
         while (rs.next())
         {
        	 itemList[i] = new ProductInventoryModel();
        	 itemList[i].setProductId(rs.getInt("productId"));
        	 itemList[i].setProductName(rs.getString("productName"));
        	 itemList[i].setProductDesc(rs.getString("description"));
        	 itemList[i].setProductType( rs.getString("type"));
        	 itemList[i].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[i].setNumAvail( rs.getInt("numAvail"));
        	 itemList[i].setThreshold(rs.getInt("threshold"));
        	 itemList[i].setSupplierID( rs.getInt("supplierID"));
        	 itemList[i].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[i].setSupplierName( rs.getInt("supplierName"));
        	 itemList[i].setNotification(rs.getString("notification"));
        	 i++;
         }

         
    	return itemList;
    }
    
    
    public  ProductInventoryModel[] getAllItemUnderThreholdList()  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[100];
    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID and (P.threshold >= (P.numAvail  + p.noOfOrder)) " ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         int i = 0;
         while (rs.next())
         {
        	 itemList[i] = new ProductInventoryModel();
        	 itemList[i].setProductId(rs.getInt("productId"));
        	 itemList[i].setProductName(rs.getString("productName"));
        	 itemList[i].setProductDesc(rs.getString("description"));
        	 itemList[i].setProductType( rs.getString("type"));
        	 itemList[i].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[i].setNumAvail( rs.getInt("numAvail"));
        	 itemList[i].setThreshold(rs.getInt("threshold"));
        	 itemList[i].setSupplierID( rs.getInt("supplierID"));
        	 itemList[i].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[i].setSupplierName( rs.getInt("supplierName"));
        	 itemList[i].setNotification(rs.getString("notification"));
        	 i++;
         }

         
    	return itemList;
    	
    }
    
    public  ProductInventoryModel[] getAllItemUnderThreholdList(int supplierId)  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[100];

    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID and (P.threshold >= (P.numAvail  + p.noOfOrder)) and p.supplierID = " + supplierId ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         int i = 0;
         while (rs.next())
         {
        	 itemList[i] = new ProductInventoryModel();
        	 itemList[i].setProductId(rs.getInt("productId"));
        	 itemList[i].setProductName(rs.getString("productName"));
        	 itemList[i].setProductDesc(rs.getString("description"));
        	 itemList[i].setProductType( rs.getString("type"));
        	 itemList[i].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[i].setNumAvail( rs.getInt("numAvail"));
        	 itemList[i].setThreshold(rs.getInt("threshold"));
        	 itemList[i].setSupplierID( rs.getInt("supplierID"));
        	 itemList[i].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[i].setSupplierName( rs.getInt("supplierName"));
        	 itemList[i].setNotification(rs.getString("notification"));
        	 i++;
         }

         
    	return itemList;
    	
    }
    
    public   ProductInventoryModel[] getAllSuppliersUnderThreholdList()  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[100];
    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID and (P.threshold >= (P.numAvail  + p.noOfOrder)) group by p.supplierID" ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         
         int j = 0;
         while (rs.next())
         {
        	// System.out.println(j);
        	 itemList[j] = new ProductInventoryModel();
        	 itemList[j].setProductId(rs.getInt("productId"));
        	 itemList[j].setProductName(rs.getString("productName"));
        	 itemList[j].setProductDesc(rs.getString("description"));
        	 itemList[j].setProductType( rs.getString("type"));
        	 itemList[j].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[j].setNumAvail( rs.getInt("numAvail"));
        	 itemList[j].setThreshold(rs.getInt("threshold"));
        	 itemList[j].setSupplierID( rs.getInt("supplierID"));
        	 itemList[j].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[j].setSupplierName( rs.getInt("supplierName"));
        	 itemList[j].setNotification(rs.getString("notification"));
        	 j++;
         }
    	return itemList;
    	
    }
    
    public void updateNotification() throws SQLException {
    	String query = "Update ProductInventory Set Notification = \"Refill\" WHERE (threshold >= (numAvail  + noOfOrder)); Update ProductInventory Set Notification = \"Full\" WHERE (threshold < (numAvail  + noOfOrder));";
    	 Statement st = conn.createStatement();
         st.executeUpdate(query);
         
    }
    
    
    public ProductInventoryModel[] getItemUnderThresholdList(int start, int end)  throws SQLException{
    	ProductInventoryModel[] itemList = new ProductInventoryModel[end - start + 1];
    	String query = "SELECT * FROM ProductInventory as P, Supplier as S  WHERE P.supplierID = s.supplierID and (P.threshold >= (P.numAvail  + p.noOfOrder)) limit "+ start  +","+ end ;
    	
    	 Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(query);
         
         int i = 0;
         while (rs.next())
         {
        	 itemList[i] = new ProductInventoryModel();
        	 itemList[i].setProductId(rs.getInt("productId"));
        	 itemList[i].setProductName(rs.getString("productName"));
        	 itemList[i].setProductDesc(rs.getString("description"));
        	 itemList[i].setProductType( rs.getString("type"));
        	 itemList[i].setProductPrice( rs.getDouble("productPrice"));
        	 itemList[i].setNumAvail( rs.getInt("numAvail"));
        	 itemList[i].setThreshold(rs.getInt("threshold"));
        	 itemList[i].setSupplierID( rs.getInt("supplierID"));
        	 itemList[i].setNoOfOrder( rs.getInt("noOfOrder"));
        	 itemList[i].setSupplierName( rs.getInt("supplierName"));
        	 itemList[i].setNotification(rs.getString("notification"));
        	 i++;
         }

         
    	return itemList;
    }
    
    public void updateNoOfOrder(int productId, int noOfOrder) throws SQLException {
    	this.noOfOrder = noOfOrder;
    	String query = "Update ProductInventory Set noOfOrder = " + noOfOrder +" where productId =" + productId;
   	 	Statement st = conn.createStatement();
        st.executeUpdate(query);
    }
    
    public String getNotification() {
		return notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getSupplierID() {
		return supplierID;
	}

	public void setSupplierID(int supplierID) {
		this.supplierID = supplierID;
	}

	public int getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(int supplierName) {
		this.supplierName = supplierName;
	}

	public void getData(String productId, String type) throws SQLException{
        
        String query = "";
        
        if(type.equals("manual"))
            query = "SELECT * FROM ProductInventory WHERE productId = " + productId;
        else {
            switch(productId) {
                case "7695045047":
                    productId = "1";
                    break;
                case "123456789012":
                    productId = "2";
                    break;
                case "781911223139":
                    productId = "3";
                    break;
                case "2527273070":
                    productId = "4";
                    break;
                case "8765432109":
                    productId = "5";
                    break;
            }
            query = "SELECT * FROM ProductInventory WHERE productId = " + productId;
        }
        
        Statement st = conn.createStatement();
        
        ResultSet rs = st.executeQuery(query);
        
        while (rs.next())
          {
            
            this.productName = rs.getString("productName");
            this.productDesc = rs.getString("description");
            this.productType = rs.getString("type");
            this.productPrice = rs.getDouble("productPrice");
            
          }
        
    }
    
    public String getProductName() {
        return productName;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public String getProductType() {
        return productType;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public int getNumAvail() {
		return numAvail;
	}

	public void setNumAvail(int numAvail) {
		this.numAvail = numAvail;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	public int getNoOfOrder() {
		return noOfOrder;
	}

	public void setNoOfOrder(int noOfOrder) {
		this.noOfOrder = noOfOrder;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public void setNumAvail(String productId, int count) throws SQLException {
        
        
        String query = "UPDATE ProductInventory SET numAvail = numAvail - " + count + " WHERE productId = " + productId;
        
        Statement st = conn.createStatement();
        
        st.executeQuery(query);
    }
    
    
}