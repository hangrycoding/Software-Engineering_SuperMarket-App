package application;
	
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;


public class CardReaderGUI extends Stage {
	
	CardReaderGUI() throws IOException{
		this.setTitle("Card Reader");
		this.setX(StagesArangement.cardReaderx);
		this.setY(StagesArangement.cardReadery);
		FXMLLoader loader = new FXMLLoader();
		//System.out.println("Working Directory = " + System.getProperty("user.dir"));
		URL cashierURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/cardReader.fxml");
        loader.setLocation(cashierURL);
        VBox vbox = loader.<VBox>load();
		
        Scene scene = new Scene(vbox,StagesArangement.cardReaderWidth,StagesArangement.cardReaderHeight);
		scene.getStylesheets().add(getClass().getResource("cardReader.css").toExternalForm());
		this.setScene(scene);
		this.show();
	}
	
}
