package application;
	
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.util.concurrent.TimeUnit;

public class popupGUI extends Stage {
	
	popupGUI() throws IOException, InterruptedException{
		
		this.setTitle("SCALE");
		this.setX(StagesArangement.cardReaderx);
		this.setY(StagesArangement.cardReadery);
		FXMLLoader loader = new FXMLLoader();
		//System.out.println("Working Directory = " + System.getProperty("user.dir"));
		URL cashierURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/popupscale.fxml");
        loader.setLocation(cashierURL);
        Pane Pane = loader.<Pane>load();
        Scene scene = new Scene(Pane,800,400);
		this.setScene(scene);
		this.centerOnScreen();
		this.show();
		
	}
	
}
