package application;

import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class CustomerLoginGUI extends Stage {
	CustomerLoginGUI(FXMLLoader LoginLoader) throws IOException{

		this.setTitle("Customer Display");
		this.setX(StagesArangement.CustomerLoginScenex);
		this.setY(StagesArangement.CustomerLoginSceney);
		
        URL CustomerLoginURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/CustomerLogin.fxml");
        LoginLoader.setLocation(CustomerLoginURL);
        Pane LoginPane = LoginLoader.<Pane>load();
        Scene LogInScene = new Scene(LoginPane, StagesArangement.CustomerLoginSceneHeight, StagesArangement.CustomerLoginSceneWidth);
        
        LogInScene.getStylesheets().add(getClass().getResource("customerLoginCSS.css").toExternalForm());
		this.setScene(LogInScene);
		//this.show();
	}
}

