package application;
	
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;


public class TillGUI extends Stage {
	
	public TillGUI() throws IOException{
		this.setTitle("Till");
		this.centerOnScreen();
		FXMLLoader loader = new FXMLLoader();
		//System.out.println("Working Directory = " + System.getProperty("user.dir"));
		URL cashierURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/till.fxml");
        loader.setLocation(cashierURL);
        Pane vbox = loader.<Pane>load();
		
        Scene scene = new Scene(vbox,200,200);
		//scene.getStylesheets().add(getClass().getResource("cardReader.css").toExternalForm());
		this.setScene(scene);
		//this.show();
	}
	
}
