package application;

import java.util.Date;

public class MakeInventoryOrderRunable implements Runnable{
	
	private boolean orderStatus;
	private Thread thread;
	private InventoryBufferAndResponse transConnector;
	private ProductInventoryModel invList[];
	private int orderNumber;
	private String supplierName;
	
	MakeInventoryOrderRunable(int orderNumber, String SupplierName, ProductInventoryModel invList[], InventoryBufferAndResponse transConnector){
		this.invList = invList;
		this.orderNumber = orderNumber;
		this.supplierName = SupplierName;
		this.transConnector = transConnector;
		
		thread = new Thread(this, "Make Inventory Order");
		thread.start();
	}
		
	@Override
	public void run() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				System.out.println("Store: Send the inventory List:");
				System.out.println("\t----------------");
				System.out.println("Order Number: " + this.orderNumber +"\tSupplier: " + this.supplierName);
				System.out.println("\t------------------------------------------------------------------------");
				System.out.println("\t |Item name" + "\t" + "Total Items|");
				for(int i = 0; i<invList.length; i++) {
					try {
						System.out.println("\t |"+ invList[i].getProductName() +"\t" + invList[i].getNoOfOrder() +"|");
						
					} catch (NullPointerException e) {
						// TODO: handle exception
					}
				}
				System.out.println("\t------------------------------------------------------------------------");
				
				this.orderStatus =  this.transConnector.makeRequestOrder(this.orderNumber, this.supplierName, this.invList);
				//this.transactionNumber = this.transConnector.getTransactionNumber();
				this.transConnector.getTransaction();
				System.out.println("Store:\t" + this.orderStatus);
		
	}
	
	public Thread getThread() {
		return thread;
	}
}
