package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CashierModel {
	
	private Connection conn = null;
	private String name;
	
	CashierModel(Connection conn){
		this.conn = conn;
	}
	
	public boolean cashierLogin(int id, String pass) throws SQLException {
		
		String query = "SELECT Name FROM CashierAccount WHERE Id = " + id + " AND Password = " + pass;
		Statement st = conn.createStatement();
		
		ResultSet rs = st.executeQuery(query);
		
		boolean isSuccess = false;
		
		while (rs.next())
	      {
	        name = rs.getString("Name");
	        isSuccess = true; 
	      }
		
		return isSuccess;
	};
	
	public String getName() {
		return name;
	}

}
