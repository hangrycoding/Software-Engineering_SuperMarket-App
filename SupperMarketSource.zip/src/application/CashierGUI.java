package application;
	
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;


public class CashierGUI extends Stage {
	
	CashierGUI(String name, FXMLLoader loader) throws IOException{
		
		this.setTitle("Cashier Register - " + name);
		
		this.setX(StagesArangement.cashierx);
		this.setY(StagesArangement.cashiery);
		
//		textbox t = loader.getID("TExtBoxID");
//		t.setText(" ");
//		loader.reload();
		
		//System.out.println("Working Directory = " + System.getProperty("user.dir"));
		URL cashierURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/cashier.fxml");
        loader.setLocation(cashierURL);
        
        
        Pane APane = loader.<Pane>load();

        Scene scene = new Scene(APane,StagesArangement.cashierWidth, StagesArangement.cashierHeight);
		scene.getStylesheets().add(getClass().getResource("cashierCSS.css").toExternalForm());
		this.setScene(scene);
        StoreController sc = loader.getController();
		this.show();
		
	}

}
