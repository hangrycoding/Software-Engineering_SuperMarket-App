package application;

import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class CustomerGUI extends Stage {
	CustomerGUI(FXMLLoader loader) throws IOException{

		this.setTitle("Customer Display");
		this.setX(StagesArangement.customerx);
		this.setY(StagesArangement.customery);
		
	
		URL customerURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/customer.fxml");
        loader.setLocation(customerURL);
        Pane APane = loader.<Pane>load();     
        
        Scene scene = new Scene(APane, StagesArangement.customerWidth,StagesArangement.customerHeight);
        scene.getStylesheets().add(getClass().getResource("customerCSS.css").toExternalForm());
		this.setScene(scene);
		
		this.show();
	}
}

