package application;

import java.io.IOException;
import javafx.concurrent.Task;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.Set;
import java.time.LocalDateTime;

import java.io.*;
public class StoreController {
	private TillGUI till ;
	private popupGUI popU;
	//cashier
	@FXML private Pane PaymentPanel;
	@FXML private TextField Name, Description, Type, Price,
							custName, custPhoneNum, custAddress, custMem, custDisc,
							cashierItemId,
							weight,
							cashierCashVal, cashierChange, checkChange,
							cashierCheckAmt, cashierCheckDate, cashierCheckTime;
	
	@FXML private ListView cashierReceiptItemName, cashierReceiptItemDesc, cashierReceiptItemPrice, cashierReceiptOrderNo,
						   printerReceiptItemName, printerReceiptItemDesc, printerReceiptItemPrice, printerReceiptOrderNo,
						   customerReceiptItemName, customerReceiptItemDesc, customerReceiptItemPrice, customerReceiptOrderNo;
	
	@FXML private Label customerName, customerPhoneNum, customerMem,
						customerNamep, customerPhoneNump, customerMemp,
						cashierName, cashierNamep,
						
						cashierTotal, printerTotal, customerTotal,
						cashierPoints, printerPoints, customerPoints,
						cashierCardReader, authCode,
						
						cashierCash,
						
						custDate, custTime,
						printerDate, printerTime,
						
						cashierTax, customerTax, printerTax,
						cashierReceiptCheckAmt, customerReceiptCheckAmt,
						cashierReceiptCashAmt, customerReceiptCashAmt,
						cashierReceiptCardAmt, customerReceiptCardAmt,
						cashierDiscount, printerDiscount, customerDiscount,
						printerCheckAmt, printerCheckDate, printerCheckTime;
	
	//customer login
	@FXML private TextField custLoginPhone;
	@FXML private PasswordField custLoginPin;
	
	//local variables
	private String cashier;
	private int orderNo = 1;
	private double total = 0; 
	
	String productName, productType, productDesc;
	double productPrice;
	
	private CustomerLoginGUI c;
	
	//checks to see if customer is already been checked
	public static boolean checkLoyal = false;
	
	//keeps track of customer information
	Connection conn = InitModel.connect();

	public CustomerModel custModel = new CustomerModel(conn);
	public ProductInventoryModel prodModel = new ProductInventoryModel(conn);
	
	
	@FXML public void initialize() {	
		try {
		PaymentPanel.setDisable(true);
		}catch (NullPointerException e) {
			// TODO: handle exception
		}
	}
	
	void setCustLogin(CustomerLoginGUI c) {
		this.c = c;
		
	}
	
	 private void calculateTol() {
		 cashierTax.setText(String.format("%.02f", total * 0.075));
		  printerTax.setText(String.format("%.02f", total * 0.075));
		  customerTax.setText(String.format("%.02f", total * 0.075));
		  
		  double disc = 0;
		  if(custModel.getIsLoyal() == 1) {
			  cashierDiscount.setText(String.format("%.02f", total * 0.05));
			  printerDiscount.setText(String.format("%.02f", total * 0.05));
			  customerDiscount.setText(String.format("%.02f", total * 0.05));
			  disc = 1;
		  }
		
		  cashierTotal.setText(String.format("%.02f", (total * 1.075) - (total * disc * 0.05)));
		  printerTotal.setText(String.format("%.02f", (total * 1.075) - (total * disc * 0.05)));
		  customerTotal.setText(String.format("%.02f", (total * 1.075) - (total * disc * 0.05)));
		  
		  
		  //update points
		  cashierPoints.setText(String.format("%.02f", (total * .10)));
		  customerPoints.setText(String.format("%.02f", (total * .10)));
		  printerPoints.setText(String.format("%.02f", (total * .10)));
		  
	 }
	  @FXML private void calculateTotal(ActionEvent event) throws IOException {
		  calculateTol();
		  PaymentPanel.setDisable(false);
		  this.till = new TillGUI();
		  this.till.show();
		 
	    }
	  
	  private void closeTill() {
		  double total_ =  Double.parseDouble(cashierTotal.getText());
		  double paid_ = 0;
		  double cash_ = Double.parseDouble( cashierReceiptCashAmt.getText());
		  double check_ = Double.parseDouble(cashierReceiptCheckAmt.getText());
		  double card_ = Double.parseDouble(cashierReceiptCardAmt.getText());
		  paid_ = cash_ + check_ + card_;
		  if(total_ <=  paid_) {
			  this.till.close();
		  }
	  }
	  
	  @FXML private void popupBtn(ActionEvent event) {
		  
		  //close the customer login screen afterwards
		  Node  source = (Node)  event.getSource();
		  Stage stage  = (Stage) source.getScene().getWindow();
		  stage.close();
	  }
	  
	  @FXML private void getCustInfo(ActionEvent event) throws IOException, SQLException{
		 
		  custModel.getData(custLoginPhone.getText(), custLoginPin.getText());
		  
		  custName.setText(custModel.getName());
		  custPhoneNum.setText(custModel.getPhoneNum());
		  custAddress.setText(custModel.getAddress());
		  
		  String loyal;
		  if(custModel.getIsLoyal() == 1) {
			  loyal = "Loyal";
			  custMem.setText("Loyal");
			  custDisc.setText("5%");
		  }
		  else {
			  loyal = "Regular";
			  custMem.setText("Regular");
			  custDisc.setText("0%");
		  }
		  
		  //customer name in customer
		  customerName.setText(custModel.getName());
		  customerPhoneNum.setText(custModel.getPhoneNum());
		  customerMem.setText(loyal);
		  
		  //customer name in printer
		  customerNamep.setText(custModel.getName());
		  customerPhoneNump.setText(custModel.getPhoneNum());
		  customerMemp.setText(loyal);
		  
		  //date
		  custDate.setText(java.time.LocalDate.now().toString());
		  printerDate.setText(java.time.LocalDate.now().toString());
			
		  SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");  
		  Date date = new Date();
		    
		  custTime.setText(formatter.format(date).toString());
		  printerTime.setText(formatter.format(date).toString());
		    
		  cashierName.setText(cashier);
		  cashierNamep.setText(cashier);
		  calculateTol();
		  
		  //close the customer login screen afterwards
		  Node  source = (Node)  event.getSource();
		  Stage stage  = (Stage) source.getScene().getWindow();
		  stage.close();
	  }
	  
	  @FXML private void manualItemId(ActionEvent event) throws IOException, SQLException, InterruptedException{
		  
		  prodModel.getData(cashierItemId.getText(), "manual");
		  
		  if(prodModel.getProductType().equals("bulk"))
			  this.popU =  new popupGUI();
		  
		  //call to the database
		  productName = prodModel.getProductName();
		  productPrice = prodModel.getProductPrice();
		  productType = prodModel.getProductType();
		  productDesc = prodModel.getProductDesc();
		  
		  //add item description
		  Name.setText(productName);
		  Description.setText(productDesc);
		  Type.setText(productType);
		  Price.setText(String.valueOf(productPrice));
		  
		  //put into cashier receipt
		  cashierReceiptItemName.getItems().add(productName);
		  
		  
		  if(productType.equals("non-bulk")) {
			  cashierReceiptItemPrice.getItems().add(String.format("%.02f", productPrice));
			  cashierReceiptItemDesc.getItems().add(productDesc);
			  total += productPrice;
		  }
		  
		  cashierReceiptOrderNo.getItems().add(orderNo);
		  
		  //customer cashier receipt
		  customerReceiptItemName.getItems().add(productName);
		  
		  
		  if(productType.equals("non-bulk")) {
			  customerReceiptItemPrice.getItems().add(String.format("%.02f", productPrice));
			  customerReceiptItemDesc.getItems().add(productDesc);
		  }
		  customerReceiptOrderNo.getItems().add(orderNo);
		  
		  //printer cashier receipt
		  printerReceiptItemName.getItems().add(productName);
		  
		  
		  if(productType.equals("non-bulk")) {
			  printerReceiptItemPrice.getItems().add(String.format("%.02f", productPrice));
			  printerReceiptItemDesc.getItems().add(productDesc);
		  }
		  
		  printerReceiptOrderNo.getItems().add(orderNo);
		  
		  orderNo++;
		  
		  if(!checkLoyal) {
			 
			  c.show();
			  checkLoyal = true;
		  }
		  
		  cashierTotal.setText(String.format("%.02f", total));
		  printerTotal.setText(String.format("%.02f", total));
		  customerTotal.setText(String.format("%.02f", total));
		  
	  }
	  
	  @FXML private void scaleItems(ActionEvent event) {
		  
		  //create a random number from 1 to 10 decimal
		  Random rand = new Random();
		  double num = rand.nextDouble(3 - 1 + 1) + 1;
		  
		  //append that to the item description
		  productDesc = productDesc + " Weight: " + String.format("%.02f", num) + " pounds";
		  
		  weight.setText(String.format("%.02f", num) + " pounds");
		  
		  //multiple the total to random number between 1-2
		  num = rand.nextDouble(1.5 - 1 + 1) + 1;
		  
		  productPrice *= num;
		  
		  total += productPrice;
		  
		  cashierReceiptItemPrice.getItems().add(String.format("%.02f", productPrice));
		  customerReceiptItemPrice.getItems().add(String.format("%.02f", productPrice));
		  printerReceiptItemPrice.getItems().add(String.format("%.02f", productPrice));
		  
		  cashierTotal.setText(String.format("%.02f", total));
		  printerTotal.setText(String.format("%.02f", total));
		  customerTotal.setText(String.format("%.02f", total));
		  
		  printerReceiptItemDesc.getItems().add(productDesc);
		  cashierReceiptItemDesc.getItems().add(productDesc);
		  customerReceiptItemDesc.getItems().add(productDesc);
		  
		  this.popU.close();
		  
		  
	  }
	  
	  @FXML private void payCheck(ActionEvent event) throws IOException, SQLException, InterruptedException {
		  
		  String Date = "", Time = "";
		  double Amount = 0.0;
		  
		  FileChooser filechooser = new FileChooser();
		  
		  filechooser.setInitialDirectory(new File(System.getProperty("user.dir")));
		  
		  File selectedFile = filechooser.showOpenDialog(new Stage());
		  
		  String fileName = selectedFile.getName().replaceFirst("[.][^.]+$", "");
		  
		  
		  SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");  
		  Date date = new Date();
		  
		  
		  switch(fileName) {
		  
		  case "1156":
			  Amount = 10;
			  Date = java.time.LocalDate.now().toString();
			  Time = formatter.format(date).toString();
			  break;
			  
			  
		  case "1613":
			  Amount = 5;
			  Date = java.time.LocalDate.now().toString();
			  Time = formatter.format(date).toString();
			  break;
		  }
		  
		  cashierCheckAmt.setText(String.format("%.02f", Amount));
		  cashierCheckDate.setText(Date);
		  cashierCheckTime.setText(Time);
		  
		  cashierReceiptCheckAmt.setText(String.format("%.02f", Amount));
		  customerReceiptCheckAmt.setText(String.format("%.02f", Amount));
		  
		  printerCheckAmt.setText("Check Amt: " + String.format("%.02f", Amount));
		  printerCheckDate.setText("Check Date: " + Date);
		  printerCheckTime.setText("Check Time: " + Time);
		  
		  checkChange.setText(String.format("%.02f", Amount - total));
		  
		  closeTill();
		  
	  }
	  @FXML private void payCash(ActionEvent event) throws IOException, SQLException, InterruptedException {
		  
		  double cash = Double.parseDouble(cashierCashVal.getText());
		  
		  cashierChange.setText(String.format("%.02f", cash - (total*1.075)));
		  
		  cashierReceiptCashAmt.setText(String.format("%.02f", cash));
		  customerReceiptCashAmt.setText(String.format("%.02f", cash));
		  
		  closeTill();
		  
	  }
	  
	  @FXML private void readCard(ActionEvent event) throws IOException, SQLException, InterruptedException {
		  
		  
		  FileChooser filechooser = new FileChooser();
		  
		  filechooser.setInitialDirectory(new File(System.getProperty("user.dir")));
		  
		  File selectedFile = filechooser.showOpenDialog(new Stage());
		  
		  String fileName = selectedFile.getName().replaceFirst("[.][^.]+$", "");
		  
		  //get data
		  custModel.getData(custLoginPhone.getText(), custLoginPin.getText());
		  
		  
		  //if even, deny
		  if(Integer.parseInt(custModel.getCardNum()) % 2 == 0) {
			  
			  cashierCardReader.setText("Card Denied. Try other option");
			  
		  }
		  else {
			  cashierCardReader.setText("Card Processed!");
			  authCode.setText("Auth code: " + java.util.UUID.randomUUID().toString());
			  
			  double amount_ = Double.parseDouble(this.cashierTotal.getText()) -  Double.parseDouble(this.cashierReceiptCashAmt.getText()) - Double.parseDouble(cashierReceiptCheckAmt.getText());
			  cashierReceiptCardAmt.setText(String.format("%.02f", (amount_)));
			  customerReceiptCardAmt.setText(String.format("%.02f", (amount_)));
			  
			  
			  TransactionBufferAndResponse tran = new TransactionBufferAndResponse();
		        //makeTransaction(String username, int accountNumber, Date ExpiredDate, int CSV, String nameHolder, double amount)
		        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		        tran.makeTransaction(customerName.getText(), 12311, Calendar.getInstance().getTime() ,123, customerName.getText(), 200);
		        tran.isApproved();
			  
		  }

		  closeTill();
		  
	  }
	  
	  @FXML private void scanBarcode(ActionEvent event) throws IOException, SQLException, InterruptedException {
		  
		  FileChooser filechooser = new FileChooser();
		  
		  filechooser.setInitialDirectory(new File(System.getProperty("user.dir")));
		  
		  File selectedFile = filechooser.showOpenDialog(new Stage());
		  
		  String fileName = selectedFile.getName().replaceFirst("[.][^.]+$", "");
		  
		  //get data
		  prodModel.getData(fileName, "barcode");
		  
		  if(prodModel.getProductType().equals("bulk"))
			  new popupGUI();
		  
		  //call to the database
		  productName = prodModel.getProductName();
		  productPrice = prodModel.getProductPrice();
		  productType = prodModel.getProductType();
		  productDesc = prodModel.getProductDesc();
		  
		  //add item description
		  Name.setText(productName);
		  Description.setText(productDesc);
		  Type.setText(productType);
		  
		  Price.setText(String.valueOf(productPrice));
		  
		  //put into cashier receipt
		  cashierReceiptItemName.getItems().add(productName);
		  cashierReceiptItemDesc.getItems().add(productDesc);
		  
		  if(productType.equals("non-bulk")) {
			  cashierReceiptItemPrice.getItems().add(productPrice);
			  total += productPrice;
		  }
		  cashierReceiptOrderNo.getItems().add(orderNo);
		  
		  //customer cashier receipt
		  customerReceiptItemName.getItems().add(productName);
		  customerReceiptItemDesc.getItems().add(productDesc);
		  
		  if(productType.equals("non-bulk"))
			  customerReceiptItemPrice.getItems().add(productPrice);
		  
		  customerReceiptOrderNo.getItems().add(orderNo);
		  
		  //printer cashier receipt
		  printerReceiptItemName.getItems().add(productName);
		  printerReceiptItemDesc.getItems().add(productDesc);
		  
		  if(productType.equals("non-bulk"))
			  printerReceiptItemPrice.getItems().add(productPrice);
		  
		  printerReceiptOrderNo.getItems().add(orderNo);
		  
		  orderNo++;
		  
		  //trigger loyal check
		  
		  if(!checkLoyal) {
			  
			  
			  c.show();
			  checkLoyal = true;
		  }
		  
		  cashierTotal.setText(String.format("%.02f", total));
		  printerTotal.setText(String.format("%.02f", total));
		  customerTotal.setText(String.format("%.02f", total));
		  
		  calculateTol();
	  }
	  
	void setCashier(String name) {
		this.cashier = name;
	}
	  
}
