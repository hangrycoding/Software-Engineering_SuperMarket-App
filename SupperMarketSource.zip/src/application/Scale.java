package application;

public class Scale {

}
