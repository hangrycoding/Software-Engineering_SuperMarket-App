package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerModel {
	
	private Connection conn = null;
	
	private String name, address, phoneNum, pin, cardNum;
	private int isLoyal;
	
	CustomerModel(Connection conn){
		this.conn = conn;
	}
	
	public void getData(String phoneNum, String pin) throws SQLException {
		
		String query = "SELECT * FROM CustomerAccount WHERE phoneNum = " + phoneNum + " AND pin = " + pin;
		
		Statement st = conn.createStatement();
		
		ResultSet rs = st.executeQuery(query);
		
		while (rs.next())
	      {
			
			this.name = rs.getString("name");
			this.address = rs.getString("address");
			this.phoneNum = rs.getString("phoneNum");
			this.pin = rs.getString("pin");
			this.isLoyal = rs.getInt("isLoyal");
			this.cardNum = rs.getString("cardNum");
			
	      }
	}

	public Connection getConn() {
		return conn;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public String getPin() {
		return pin;
	}

	public int getIsLoyal() {
		return isLoyal;
	}
	
	public String getCardNum() {
		return cardNum;
	}

}
