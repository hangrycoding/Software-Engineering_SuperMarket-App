package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SupplierModel {
	private int supplierID;
	private String supplierName;
	private String phone;
	private String address;
	
	private Connection conn = null;

	
	
	
	public void LoadSupplierModel(int supplierID) throws SQLException{
		String query = "SELECT * FROM Supplier WHERE supplierID = " + supplierID ;
		Statement st = conn.createStatement();
		st.executeQuery(query);
				
		ResultSet rs = st.executeQuery(query);

		this.supplierID = supplierID;
		this.supplierName = rs.getString("SupplierName");
		this.phone = rs.getString("Phone");
		this.address = rs.getString("address");
		
	}
	
	
	
	
	
	public SupplierModel(Connection conn) {
		super();
		this.conn = conn;
	}

	public int getSupplierID() {
		return supplierID;
	}

	public void setSupplierID(int supplierID) {
		this.supplierID = supplierID;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
