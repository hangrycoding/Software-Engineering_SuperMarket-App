package application;
	
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Timer;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class Main extends Application {
	
    @FXML private void LogInCashier(ActionEvent event) throws IOException {
    	new CashierLoginGUI();
    }
    
    @FXML private void LogInMangeInventory(ActionEvent event) throws IOException, InterruptedException {
    		
    	InventoryManagementController InvController = new InventoryManagementController();
	   	
    	FXMLLoader loader2 = new FXMLLoader();
    	loader2.setController(InvController);  
	   	new InventoryManagementGUI(loader2);
	   	
	   	
	   	FXMLLoader loader3 = new FXMLLoader();
	   	loader3.setController(InvController); 
	   	new OrderItemListPopUpGUI(loader3);
	   	
    }
    
	@Override
	public void start(Stage primaryStage) throws IOException {
		
		primaryStage.setTitle("Check Out System");
		primaryStage.centerOnScreen();
		
		FXMLLoader loader = new FXMLLoader();
	
		URL URL_ = new URL("file:///" + System.getProperty("user.dir") + "/src/application/main.fxml");
        loader.setLocation(URL_);
		VBox vbox = loader.<VBox>load();
        
        Scene scene = new Scene(vbox, 400,400);
        scene.getStylesheets().add(getClass().getResource("mainCSS.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
        
	}
	
	public static void main(String[] args) {
		
		//Create timer
	  	OrderSupplyTimerThread orderSupplyTimer = new OrderSupplyTimerThread();
        Timer t = new Timer();
        t.schedule(orderSupplyTimer, 0, 30000);//  executes for every 10 seconds
        
		launch(args);
		
	}
}
