package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ProductModel {
	
	private Connection conn = null;
	
	ProductModel(Connection conn){
		this.conn = conn;
	}
	
	
	public String getProductNameById(int productId) {
		return "";
	}
	
	public double getProductPriceById(int productId) {
		return 0;
	}
	
	public String getProductNameByBarcode(String barcodeId) {
		return "";
	}
	
	public double getProductPriceByBarcode(String barcodeId) {
		return 0;
	}
	
	public void setNumAvail() {
		
	}
	
	
}
