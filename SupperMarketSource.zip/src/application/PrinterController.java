package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
public class PrinterController {
	 
	@FXML private TextField Name, Description, Type, Price;
	
	@FXML private static ListView printerReceiptItemName;

	@FXML
	private static ListView printerReceiptItemDesc;

	@FXML
	private static ListView printerReceiptItemPrice;

	@FXML
	private static ListView printerReceiptOrderNo;
	
	private String name;
	
	Connection conn = InitModel.connect();
	
	void initialize() {}
	
	  @FXML private void calculateTotal(ActionEvent event) throws IOException {
	    	
	    }
	  
	  public static void updateReceipt(int orderNo, String productName, String productDesc, double productPrice ) {
		  
		  //put into printer receipt
		  printerReceiptItemName.getItems().add(productName);
		  printerReceiptItemDesc.getItems().add(productDesc);
		  printerReceiptItemPrice.getItems().add(productPrice);
		  printerReceiptOrderNo.getItems().add(orderNo);
		  
		  orderNo++;
	  }
		  
	  
	void retrieveName(String name) {
		this.name = name;
	}
	  
}
