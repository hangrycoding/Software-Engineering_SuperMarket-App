package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

public class InventoryOrdersModel {
	//return itemDescript
	private int supplierId;
	private int orderId;
	private int orderStatus;
	private String orderDate;
	private Connection conn = null;
	private ProductInventoryModel productList[];
	private SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	private String supplierName;
	
	private int productID;
	private String productName;
	private int noOfOrder;

	public String getOrderStatusString(){
		if(this.orderStatus ==0) {
			return "Restock";
		}
		return "Sent";
	}
	{
		
		orderId = -1;
		supplierId = -1;
		productList = null;
	}

	
    
 public InventoryOrdersModel() {
		super();
	}



public void makeOrder(int supplierId, ProductInventoryModel productList[])  throws SQLException{
    	
    	String query = "INSERT into InventoryOrder (supplierID) values (" + supplierId  +")"  ;
		Statement st = conn.createStatement();
		st.execute(query);
		
		query = "select max(OrderId) as ordId from InventoryOrder";
		
		ResultSet rs = st.executeQuery(query);
		this.orderId = rs.getInt("ordId");
		
		
		for(int i=0; i<productList.length; i++) {
			try {
				addItem(this.orderId, productList[i].getProductId());
			}catch (IndexOutOfBoundsException e) {
				
				// TODO: handle exception
			}catch (NullPointerException e) {
				// TODO: handle exception
			}
		}
		
    	
    }
    
 
    public void addItem(int orderId, int productId) throws SQLException {
    	
    	String query = "Insert into InventoryOrderItems (OrderId, productId) values (" +orderId + ","+ productId +")"  ;
    	Statement st = conn.createStatement();
		st.execute(query);
		
		//update productInventory 
		ProductInventoryModel p = new ProductInventoryModel(conn);
		p.updateNoOfOrder(productId, 20);
    }
    
    public InventoryOrdersModel[] requestOrderList() throws SQLException {
    	InventoryOrdersModel[] orderlist = new InventoryOrdersModel[100];
    	String query = "Select * from InventoryOrder as I, Supplier as S where I.supplierID = S.supplierID"  ;
    	Statement st = conn.createStatement();
		ResultSet rs =  st.executeQuery(query);
		
		
		int i = 0;
		 while (rs.next()){
			
    		try {
    			//System.out.println(i);
    			orderlist[i] = new InventoryOrdersModel();
    			orderlist[i].setOrderId(rs.getInt("OrderId"));
    			orderlist[i].setSupplierId(rs.getInt("supplierID"));
    			orderlist[i].setOrderStatus(rs.getInt("orderStatus"));
    			orderlist[i].setOrderDate( this.dateFormat.format(rs.getDate("OrderDate")));
    			orderlist[i].setSupplierName(rs.getString("SupplierName"));
    	
    			i++;
    		}catch (NullPointerException e) {
				// TODO: handle exception
    			e.printStackTrace();
			}
    	}
    	
    	return orderlist;
    }

    public int getProductID() {
		return productID;
	}



	public void setProductID(int productID) {
		this.productID = productID;
	}



	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}



	public int getNoOfOrder() {
		return noOfOrder;
	}



	public void setNoOfOrder(int noOfOrder) {
		this.noOfOrder = noOfOrder;
	}



	public InventoryOrdersModel[] requestOrderList(int orderID) throws SQLException {
    	InventoryOrdersModel[] orderlist = new InventoryOrdersModel[100];
    	String query = "select * from InventoryOrderItems as I, ProductInventory as P where I.productId = P.productId and I.OrderId = " + orderID  ;
    	Statement st = conn.createStatement();
		ResultSet rs =  st.executeQuery(query);
		
		int i = 0;
		 while (rs.next()){
			
    		try {
    			//System.out.println(i);
    			orderlist[i] = new InventoryOrdersModel();
    			
    			orderlist[i] = new InventoryOrdersModel();
    			orderlist[i].setOrderId(rs.getInt("OrderId"));
    			orderlist[i].setProductID(rs.getInt("productId"));
    			orderlist[i].setProductName(rs.getString("productName"));
    			orderlist[i].setNoOfOrder(rs.getInt("noOfOrder"));
    	
    			i++;
    			
    			i++;
    		}catch (NullPointerException e) {
				// TODO: handle exception
    			System.out.println(e.toString());
			}
    	}
    	
    	return orderlist;
    }
	public String getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public String getSupplierName() {
		return supplierName;
	}


	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}


	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public int getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(int orderStatus) {
		this.orderStatus = orderStatus;
	}

	    
    InventoryOrdersModel(Connection conn){
        this.conn = conn;
    }


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public ProductInventoryModel[] getProductList() {
		return productList;
	}


	public void setProductList(ProductInventoryModel[] productList) {
		this.productList = productList;
	}


	public Connection getConn() {
		return conn;
	}



}
