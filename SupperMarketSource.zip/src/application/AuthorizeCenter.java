package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class AuthorizeCenter implements Runnable{
	private boolean transNum;
	private boolean status;
	private double chargedAmount;
	private SimpleDateFormat dateFormat;
	private int CSV;
	private Date transactionDate;
	TransactionBufferAndResponse transConnector;
	private int accountNumber;
	private Date ExpireDate;
	private String name = "Someone";
	Thread thread;
	public AuthorizeCenter(TransactionBufferAndResponse trans, int AcountNumber, Date ExpiredDate, String nameHolder){
		//System.out.println("Create an object of BankTransaction");
		this.accountNumber = AcountNumber;
		this.ExpireDate = ExpiredDate;
		this.name = nameHolder;
		this.transConnector = trans;
		thread = new Thread(this, "Authorization Center");
		thread.start();
	}
	public AuthorizeCenter() {
		// TODO Auto-generated constructor stub
	}
	//initial variables
	{
		//initial value for: 
		this.transactionDate = Calendar.getInstance().getTime();
		this.status = false;
		this.chargedAmount = 0;
		this.CSV = -1;
		this.accountNumber = 0;
		
		//get newest transaction number, this is a bad way to encypt the transaction number


		dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	}
	

	public boolean verifyTransaction(int AcountNumber, Date ExpiredDate, String nameHolder) {
		// Check if credit card is valid
		System.out.println("check = " + AcountNumber + ": " +  (AcountNumber%2 == 0));
//		return AcountNumber%2 == 0;
		return true;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Authorization Center is running");
		this.transConnector.receive();
		System.out.println("Authorization Center:\t Start to making the transaction request");

		//Charge money
		
		
		//set back transaction number for conectors. clear request.
		Boolean isApproved =  verifyTransaction(this.accountNumber , transactionDate, name );
		System.out.println("Authorization Center:\t Is approved: " + isApproved);
		this.transConnector.responseCharge(isApproved);
	}

		
	
}
