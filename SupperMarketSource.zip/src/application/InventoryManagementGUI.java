package application;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;

public class InventoryManagementGUI extends Stage {
	InventoryManagementGUI(FXMLLoader loader) throws IOException{

		this.setTitle("Inventory Managerment");
		this.centerOnScreen();
		
//		FXMLLoader loader = new FXMLLoader();
	
		URL customerURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/InventoryManagement.fxml");
        loader.setLocation(customerURL);
        Pane APane = loader.<Pane>load();
      
        Scene scene = new Scene(APane, StagesArangement.inventoryWidth,StagesArangement.inventoryHeight);
        scene.getStylesheets().add(getClass().getResource("customerCSS.css").toExternalForm());
		this.setScene(scene);
		this.show();
	}
	

}

