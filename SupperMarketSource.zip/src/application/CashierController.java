package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CashierController {
	
	@FXML private TextField id;
	@FXML private PasswordField password;

	
	Connection conn = InitModel.connect();
	
	  @FXML private void calculateTotal(ActionEvent event) throws IOException {
	    	
	    }
	  
	  
	  @FXML private void loginAccount(ActionEvent event) throws IOException, SQLException {
		  
		  CashierModel cashier = new CashierModel(conn);
		  
		  if(cashier.cashierLogin(Integer.parseInt(id.getText()), password.getText())) {
			  
			  //starts the checkout system
			  
			  StoreController StoreController = new StoreController();
			  
			  StoreController.setCashier(cashier.getName());
			  FXMLLoader loader = new FXMLLoader();
			  loader.setController(StoreController);
			  new CashierGUI(cashier.getName(), loader);
			  
			  
			  FXMLLoader loader2 = new FXMLLoader();
			  loader2.setController(StoreController);
			  new CustomerGUI(loader2);
			  
			  FXMLLoader loader3 = new FXMLLoader();
			  loader3.setController(StoreController);
			  new PrinterGUI(loader3);
			  
			  FXMLLoader loader4 = new FXMLLoader();
			  loader4.setController(StoreController);
			  CustomerLoginGUI c = new CustomerLoginGUI(loader4);
			  
			  
			  StoreController.setCustLogin(c);
			  
			  Node  source = (Node)  event.getSource();
			  Stage stage  = (Stage) source.getScene().getWindow();
			  stage.close();
		  }
		  
		  else {
			  System.out.println("Cashier not detected.");
		  }
		  
	  }
}
