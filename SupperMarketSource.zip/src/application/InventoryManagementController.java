package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;


public class InventoryManagementController  {
	Connection conn = InitModel.connect();
	private int itemsPerPage = 20;
	private Boolean isFindUnder = false;
	private String searchKey = "";
	private int stageList = 0;
	
	@FXML	private  TextField 	minuteTextField;
	@FXML	private  TextField  hourTextField;
//		@FXML private TextField id;
	//
	@FXML	private  ListView 	NoList;
	@FXML	private  ListView 	ItemIDList;
	@FXML	private  ListView 	ItemNameList;
	@FXML	private  ListView 	PriceList;
	@FXML	private  ListView 	AvailableList;
	@FXML	private  ListView 	thresholdList;
	@FXML	private  ListView 	SupplierList;
	@FXML	private  ListView 	NotificationList;
	@FXML	private  ListView 	NoOfOrderList;
	@FXML	private  Pagination PagesList;
			
	@FXML	private  Button findUnderButton;
	@FXML	private  TextField searchTextField;

	
	@FXML	private  ListView 	orderIDList;
	@FXML	private  ListView 	NoList2;
	@FXML	private  ListView 	SupNameList;
	@FXML	private  ListView 	DateList;
	@FXML	private  ListView 	StatusList;
	//
	@FXML private Label printerLabel;
	
	
	@FXML	private  ListView 	NoList3;
	@FXML	private  ListView 	itemID2List;
	@FXML	private  ListView 	itemName2List;
	@FXML	private  ListView 	NoOfOrder2List;
	@FXML	private  Label 	orderNumberLabel;
	
		
	@FXML private void searchItems(ActionEvent event) throws IOException {
		stageList = 2;
		if(searchTextField.getText() == "") {
			clearItemList();
			clearOrderList();
			initialize();
		}else if(searchTextField.getText().toLowerCase() == searchKey) {
			//donothing
		}else{
			searchKey = searchTextField.getText();
			clearItemList();
			ProductInventoryModel inv = new ProductInventoryModel(conn);
			try {
				int currentPage = PagesList.getCurrentPageIndex();
				//System.out.println(currentPage);
				ProductInventoryModel invList[];
				if(isFindUnder == true) {
					invList = inv.getItemSearchUnderThresholdList((currentPage)*itemsPerPage, (currentPage)*itemsPerPage + itemsPerPage, searchKey);
				}
				else {
					invList = inv.getSearchItemList((currentPage)*itemsPerPage, (currentPage)*itemsPerPage + itemsPerPage, searchKey);
				}
				
				
				loadItemList(currentPage,invList);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}
	
	@FXML private void findItemUnderThreshold(ActionEvent event) throws IOException {
		stageList = 1;
		isFindUnder = true;

		clearItemList();
		if(findUnderButton.getText() == "Exit") {
			initialize();
		}else {
			findUnderButton.setText("Exit");
			searchKey = "";
			searchTextField.setText("");
			ProductInventoryModel inv = new ProductInventoryModel(conn);
			try {
				int currentPage = PagesList.getCurrentPageIndex();
				//System.out.println(currentPage);
				ProductInventoryModel invList[] = inv.getItemUnderThresholdList((currentPage)*itemsPerPage, (currentPage)*itemsPerPage + itemsPerPage);
				loadItemList(currentPage,invList);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    }
	
	@FXML void initialize() {
		stageList = 0;
		loadTimer();
		 isFindUnder = false;
		 findUnderButton.setText("Find Item Under Threshold");
		 searchTextField.setText("");
		 clearOrderList();
		clearItemList();
		ProductInventoryModel inv = new ProductInventoryModel(conn);
		try {
			int currentPage = PagesList.getCurrentPageIndex();
			
			ProductInventoryModel invList[] = inv.getItemList((currentPage)*itemsPerPage, (currentPage)*itemsPerPage + itemsPerPage);
			loadItemList(currentPage,invList );
			
			InventoryOrdersModel inOr = new InventoryOrdersModel(conn);
			InventoryOrdersModel [] orderL = inOr.requestOrderList();
			loadOrderList(currentPage, orderL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML 
	private void setOrderSupplyTime(ActionEvent event) throws IOException  {
		
		//System.out.println(hourTextField.getText() + ": " + minuteTextField.getText());
		
		String timerFile = System.getProperty("user.dir") + "/src/application/Time.txt";
		BufferedWriter writer;
		try {
			//write to transaction file
			writer = new BufferedWriter(new FileWriter(timerFile, false ));
		    writer.append(this.hourTextField.getText() + ":" + this.minuteTextField.getText());
		    writer.close();
		  
		} catch (IOException ioe) {
		    System.err.format("IOException: %s%n", ioe);
		    
		}
		
	}
	
	public void loadTimer() {
		
		String timerFile = System.getProperty("user.dir") + "/src/application/Time.txt";
			try {
						BufferedReader reader = new BufferedReader(new FileReader(timerFile));
						
						String line = reader.readLine();
						String breakLine[] = line.split(":");
						hourTextField.setText(breakLine[0]);
						minuteTextField.setText(breakLine[1]);
						reader.close();
					} catch (IOException e) {
						
		} 
	}
	
	@FXML public void orderListOnClick(MouseEvent arg0) throws IOException, InterruptedException, SQLException {
	    //System.out.println("clicked on " + orderIDList.getSelectionModel().getSelectedItem());
	    InventoryOrdersModel inv = new InventoryOrdersModel(conn);
	    try{
		    InventoryOrdersModel[] ItemList = inv.requestOrderList((int) orderIDList.getSelectionModel().getSelectedItem());
		    clearOrderItems();
		    loadOrderItems(5, ItemList);}
	    catch (NullPointerException e) {
			// TODO: handle exception
		}
	

	}
	
	public void loadOrderList(int currentPage, InventoryOrdersModel[] orderList) {
		//System.out.println("Load Order List");
		for(int i = 0; i<itemsPerPage ; i++) {
			 try {
 				
				//System.out.println(orderList[i].getOrderId());
				 NoList2.getItems().add((0)*itemsPerPage + i+1);
				 orderIDList.getItems().add(orderList[i].getOrderId());
				 SupNameList.getItems().add(orderList[i].getSupplierName());
				 DateList.getItems().add(orderList[i].getOrderDate());
				 StatusList.getItems().add(orderList[i].getOrderStatus());
				
				
			} catch (NullPointerException e) {
				// TODO: handle exception
			}
			
		}
	}
	public void loadOrderItems(int currentPage, InventoryOrdersModel[] invList ) throws NullPointerException{

		orderNumberLabel.setText(String.valueOf(invList[0].getOrderId()));
		for(int i = 0; i<itemsPerPage ; i++) {
			 try {
					
					NoList3.getItems().add((0)*itemsPerPage + i+1);
					itemID2List.getItems().add(invList[i].getProductID());
					itemName2List.getItems().add(invList[i].getProductName());
					NoOfOrder2List.getItems().add(invList[i].getNoOfOrder());
			
				
			} catch (NullPointerException e) {
				// TODO: handle exception
				//e.printStackTrace();
			//	System.out.println("227 -InventoryManangementController");
			}
			
		}
	}
	
	public void loadItemList(int currentPage, ProductInventoryModel invList[] ) {
		for(int i = 0; i<itemsPerPage ; i++) {
			 try {
				 //System.out.println(i);
				 NoList.getItems().add((currentPage)*itemsPerPage + i+1);
				ItemIDList.getItems().add(invList[i].getProductId());
				ItemNameList.getItems().add(invList[i].getProductName());
				PriceList.getItems().add(invList[i].getProductPrice());
				AvailableList.getItems().add(invList[i].getNumAvail());
				thresholdList.getItems().add(invList[i].getThreshold());
				SupplierList.getItems().add(invList[i].getSupplierName());
				NotificationList.getItems().add(invList[i].getNotification());
				NoOfOrderList.getItems().add(invList[i].getNoOfOrder());
				
			} catch (NullPointerException e) {
				// TODO: handle exception
			}
			
		}
	}
	
	 
	private void clearOrderList() {
		NoList2.getItems().clear();
		orderIDList.getItems().clear();
		SupNameList.getItems().clear();
		DateList.getItems().clear();
		StatusList.getItems().clear();
	}
	private void clearOrderItems() {
		orderNumberLabel.setText("");
		NoList3.getItems().clear();
		itemID2List.getItems().clear();
		itemName2List.getItems().clear();
		NoOfOrder2List.getItems().clear();
	}
	private void clearItemList() {
		NoList.getItems().clear();;
		ItemIDList.getItems().clear();;
		ItemNameList.getItems().clear();;
		PriceList.getItems().clear();;
		AvailableList.getItems().clear();;
		thresholdList.getItems().clear();;
		SupplierList.getItems().clear();;
		NotificationList.getItems().clear();;
		NoOfOrderList.getItems().clear();;
		PagesList.setCurrentPageIndex(0);
	}
	
}
