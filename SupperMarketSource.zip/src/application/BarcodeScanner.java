package application;

public class BarcodeScanner {

}
