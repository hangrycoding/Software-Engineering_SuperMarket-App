package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

public class OrderSupplyTimerThread  extends TimerTask{
	Connection conn = InitModel.connect();
	private int hour;
	private int minute;
	{
	
	
	}
	
	
   public OrderSupplyTimerThread() {
		super();
	}

   public OrderSupplyTimerThread(int hour, int minute) {
		super();
		this.hour = hour;
		this.minute = minute;
	
	}
   
   public void pause() {
	    this.cancel();
	}
   
   public void resume() {
	    
	}

public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getMinute() {
		return minute;
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}


	public void getInventoryOrder() throws InterruptedException {
 
		
		ProductInventoryModel inv = new ProductInventoryModel();
		 inv.setConnection(conn);
			try {
				

				ProductInventoryModel invList[] = inv.getAllItemUnderThreholdList();
					
				for(int i = 0; i<5; i++) {

					try {
						
						
					} catch (NullPointerException e) {
						// TODO: handle exception
					}
				}
			 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	    LocalDateTime now = LocalDateTime.now();  
//	    pause();
//	    resume();
		String timerFile = System.getProperty("user.dir") + "/src/application/Time.txt";
		try {
					BufferedReader reader = new BufferedReader(new FileReader(timerFile));
					
					String line = reader.readLine();
					String breakLine[] = line.split(":");
					this.hour = Integer.parseInt(breakLine[0]);
					this.minute = Integer.parseInt(breakLine[1]);
					reader.close();
				} catch (IOException e) {
					
				} 
		
	    	System.out.println(this.getHour() + ":"+ this.getMinute() + "=="   + now.getHour() +":"+ now.getMinute());
		 if(this.getHour() == now.getHour() && this.getMinute() == now.getMinute()) {
		 	 //getItem under threshold 
			 ProductInventoryModel inv = new ProductInventoryModel();
			 inv.setConnection(conn);
			 try {
				 	System.out.println("Send Orders");
					ProductInventoryModel supList[] = inv.getAllSuppliersUnderThreholdList();
					ProductInventoryModel itemList[] = null;
					InventoryOrdersModel InOrd = new InventoryOrdersModel(conn);
					SupplierModel sup = new SupplierModel(conn);
					
					for(int i = 0; i< supList.length; i++) {
						try {
						itemList = inv.getAllItemUnderThreholdList(supList[i].getSupplierID());
						InOrd.makeOrder(supList[i].getSupplierID(), itemList);
						sup.LoadSupplierModel(supList[i].getSupplierID());
						InventoryBufferAndResponse.makeOrderChanel(InOrd.getOrderId(), sup.getSupplierName() , itemList);
						}catch (NullPointerException e) {
							// TODO: handle exception
						}
					}
					
					
					//Make order
					
					//System.out.println("GET INT HERE");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		 } else {
			 ProductInventoryModel inv = new ProductInventoryModel();
			 inv.setConnection(conn);
			
			try {
					inv.updateNotification();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 System.out.println("Tracking inventory");
			
			 //trigger from database
		 }
		 
		
	}
	
}