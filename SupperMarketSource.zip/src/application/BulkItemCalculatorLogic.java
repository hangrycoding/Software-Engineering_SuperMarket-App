package application;

public class BulkItemCalculatorLogic {

}
