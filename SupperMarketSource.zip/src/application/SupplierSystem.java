package application;

import java.util.Date;

public class SupplierSystem implements Runnable{
	private String status;
	InventoryBufferAndResponse transConnector;
	Thread thread;
	public SupplierSystem(InventoryBufferAndResponse buff){
		//System.out.println("Create an object of BankTransaction");
		this.transConnector = buff;
		thread = new Thread(this, "Supplier");
		thread.start();
	}
	


	@Override
	public void run() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				System.out.println("Supplier is running");
				this.transConnector.receive();
				System.out.println("Supplier:\t Start to making the transaction request");
								
				//Repair order and ship
				ProductInventoryModel orderList[] = this.transConnector.getInvList();
				for(int i = 0; i<orderList.length; i++) {
					try {
						orderList[i].getProductName();
					} catch (NullPointerException e) {
						// TODO: handle exception
					}
				}
				//set back transaction number for conectors. clear request.
				System.out.println("Supplier:\tTransaction Number: " + "order is in Progess");
				this.transConnector.setOrderStatus(true);
				this.transConnector.responseOrder(true);
	}

}
