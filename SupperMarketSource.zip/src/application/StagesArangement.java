package application;

public class StagesArangement {
	private static int stageDistance = 5;
	private static int stageMaxHeight = 1000;
	public static int cashierWidth = 1100;
	public static int cashierHeight = stageMaxHeight;
	public static int cashierx = 0;
	public static int cashiery = 0;
	public static int customerWidth = 400;
	public static int customerHeight = stageMaxHeight;
	public static int customerx = cashierx + cashierWidth + stageDistance;
	public static int customery = 0;
	public static int printerWidth = 400;
	public static int printerHeight = stageMaxHeight;
	public static int printerx = customerx + customerWidth + stageDistance;
	public static int printery = 0;
	public static int cardReaderWidth = 400;
	public static int cardReaderHeight = stageMaxHeight/2-40;
	public static int cardReaderx = 0;//printerx + printerWidth + stageDistance;
	public static int cardReadery = 0;
	public static int inventoryWidth = 1200;
	public static int inventoryHeight = 900;
	public static int inventoryx = 0;
	public static int inventoryy = 0;
	
	public static int CustomerLoginSceneHeight = customerWidth - 40;
	public static int CustomerLoginSceneWidth = 200;
	public static int CustomerLoginScenex= customerx + 20;
	public static int CustomerLoginSceney = customerHeight/2;
	
	public static int CashierLoginSceneHeight = 360;
	public static int CashierLoginSceneWidth = 200;
	public static int CashierLoginScenex= customerx + 20;
	public static int CashierLoginSceney = customerHeight/2;
	
}
