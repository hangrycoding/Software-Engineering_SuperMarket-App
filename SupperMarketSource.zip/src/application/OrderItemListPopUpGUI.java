package application;
	
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.util.concurrent.TimeUnit;

public class OrderItemListPopUpGUI extends Stage {
	
	OrderItemListPopUpGUI(FXMLLoader loader) throws IOException, InterruptedException{
		
		this.setTitle("Order's Items");
		this.setX(1570);
		this.setY(100);
//		FXMLLoader loader = new FXMLLoader();
		//System.out.println("Working Directory = " + System.getProperty("user.dir"));
		URL cashierURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/OrderItemList.fxml");
        loader.setLocation(cashierURL);
        Pane Pane = loader.<Pane>load();
        Scene scene = new Scene(Pane,300,800);
		this.setScene(scene);
		this.show();
		
	}
	
}
