package application;

import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class CashierLoginGUI extends Stage {
	
	CashierLoginGUI() throws IOException{

		this.setTitle("Cashier Display");
		this.setX(StagesArangement.CashierLoginScenex);
		this.setY(StagesArangement.CashierLoginSceney);
		
        URL CashierLoginURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/CashierLogin.fxml");
        FXMLLoader LoginLoader = new FXMLLoader();
        LoginLoader.setLocation(CashierLoginURL);
        Pane LoginPane = LoginLoader.<Pane>load();
        Scene LogInScene = new Scene(LoginPane, StagesArangement.CashierLoginSceneHeight, StagesArangement.CashierLoginSceneWidth);
        
        //LogInScene.getStylesheets().add(getClass().getResource("customerLoginCSS.css").toExternalForm());
		this.setScene(LogInScene);
		this.show();
	}
}

