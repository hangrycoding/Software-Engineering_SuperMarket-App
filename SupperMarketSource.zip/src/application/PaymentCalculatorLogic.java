package application;

public class PaymentCalculatorLogic {

}
