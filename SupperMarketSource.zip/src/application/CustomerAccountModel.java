package application;

public class CustomerAccountModel {

}
