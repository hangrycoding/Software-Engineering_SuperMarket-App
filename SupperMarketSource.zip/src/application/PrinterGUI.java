package application;

import javafx.stage.Stage;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class PrinterGUI extends Stage{

	PrinterGUI(FXMLLoader loader) throws IOException {
		
		this.setTitle("Printer");	
		this.setX(StagesArangement.printerx);
		this.setY(StagesArangement.printery);
		
		URL printerURL = new URL("file:///" + System.getProperty("user.dir") + "/src/application/printer.fxml");
        loader.setLocation(printerURL);
        Pane APane = loader.<Pane>load();
        
        Scene scene = new Scene(APane,StagesArangement.printerWidth,StagesArangement.printerHeight);
        scene.getStylesheets().add(getClass().getResource("customerCSS.css").toExternalForm());
		this.setScene(scene);
		this.show();
	}
}
