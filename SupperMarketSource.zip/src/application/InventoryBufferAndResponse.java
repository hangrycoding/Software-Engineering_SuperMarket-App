package application;

import java.text.SimpleDateFormat;
import java.util.Date;

public class InventoryBufferAndResponse {
	private boolean orderStatus;
	private SimpleDateFormat dateFormat;
	private boolean request = false;
	private boolean response = false;
	private ProductInventoryModel invList[];
	private int orderID;
	private String supplierName;
	{
		orderID = -1;
		supplierName = "Texas Tech";
		this.orderStatus=false;
		this.dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	}
	static boolean makeOrderChanel(int orderId, String suppliernName, ProductInventoryModel itemList[]) {
		InventoryBufferAndResponse transConnector = new InventoryBufferAndResponse();
		transConnector.invList = itemList;
		SupplierSystem supplier = new SupplierSystem(transConnector);
		MakeInventoryOrderRunable makeOrder;
		
		try {
			
			makeOrder = new MakeInventoryOrderRunable(orderId, suppliernName,  itemList, transConnector);//need parameters
			transConnector.getOrderStatus();
			supplier.thread.join();
			makeOrder.getThread().join();
		
		} catch ( InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("end");
		return transConnector.getOrderStatus();
	}
	
	synchronized public boolean getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(boolean orderStatus) {
		this.orderStatus = orderStatus;
	}

	synchronized boolean makeRequestOrder(int orderId, String SupplierName, ProductInventoryModel itemList[] ) {
		 System.out.println("Store:\t Send order: Done");
		this.invList = itemList;
	   	  this.request = true;
		 notify();
		//while not response, send request
		while(this.response == false) {
		      try {
		    	  System.out.println("------------------------------");
		    	  System.out.println("Store:\t is waiting for response\n");
		    	  
		    	  wait();
		    	  
		      } catch(InterruptedException e) {
		        System.out.println("InterruptedException caught");
		      }
		      System.out.println("------------------------------");
		      System.out.println("Store:\t Status: " + this.orderStatus);
		      System.out.println("*****************************");
		      return this.orderStatus;
		}
		return this.orderStatus;
		
	}
	synchronized public ProductInventoryModel[] getInvList() {
		return invList;
	}

	public void setInvList(ProductInventoryModel[] invList) {
		this.invList = invList;
	}

	synchronized boolean getTransaction() {
	      
	      //get response, clear response
	  this.request = false;
      this.response = false;
      notify();
      return this.orderStatus;
	}
	
	synchronized void receive() {
		//if recieve request, return transaction status/value
		while(request == false) {
			
			      try {
			    	  
			    	System.out.println("------------------------------");
			        System.out.println("Supplier:\t is waiting for a transaction request"); 
			       // System.out.println(this.accountNumber);
			      //response for the request
			        wait();
			        

			      } catch(InterruptedException | NumberFormatException e) {
			        System.out.println("InterruptedException caught");
			      }
			      
		}
	}
	synchronized boolean responseOrder(boolean status) {
		
		 this.orderStatus = status;
		  response = true;
	      this.request = false;
	      notify();
	      return this.orderStatus;
	}

}
